package com.axess.smartbankapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartBankApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
