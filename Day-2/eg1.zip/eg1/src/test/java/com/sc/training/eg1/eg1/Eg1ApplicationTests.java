package com.sc.training.eg1.eg1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eg1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
