package com.example.demosample2jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSample2JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
