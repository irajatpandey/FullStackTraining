package com.example.demosample2jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSample2JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSample2JpaApplication.class, args);
	}

}
