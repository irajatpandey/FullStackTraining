package com.example.demosample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
